package com.tastyfood.order.my.food.usermanagementservice.model;

public enum RoleName {
    ROLE_USER,
    ROLE_ADMIN
}
