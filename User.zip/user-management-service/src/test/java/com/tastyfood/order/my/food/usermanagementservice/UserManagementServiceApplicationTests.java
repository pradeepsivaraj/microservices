/*package com.tastyfood.order.my.food.usermanagementservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserManagementServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
*/