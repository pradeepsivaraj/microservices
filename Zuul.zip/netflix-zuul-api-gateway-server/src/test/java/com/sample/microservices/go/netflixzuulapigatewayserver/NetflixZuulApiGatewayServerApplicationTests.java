/*package com.sample.microservices.go.netflixzuulapigatewayserver;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NetflixZuulApiGatewayServerApplicationTests {

	@Test
	void contextLoads() {
	}

}*/